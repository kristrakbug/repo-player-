// Plyxe bridge. Preserve the provider's HTTP URL, port and query string.
// Optional Worker secret BRIDGE_KEY restricts access to your PHP installation.
// Redirect cookies stay inside this request and are never sent to another origin.
function targetURL(value) {
  let url;
  try { url = new URL(value); } catch { throw new Error('URL no válida.'); }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error('URL no válida.');
  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  // Workers cannot reach private networks; also reject obvious private targets early.
  if (host === 'localhost' || !host.includes('.') || /\.(local|internal|localhost)$/.test(host) || host.includes(':')) throw new Error('Destino no permitido.');
  if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) {
    const [a,b] = host.split('.').map(Number);
    if ([0,10,127].includes(a) || a >= 224 || (a===169&&b===254) || (a===172&&b>=16&&b<=31) || (a===192&&b===168) || (a===100&&b>=64&&b<=127)) throw new Error('Destino no permitido.');
  }
  return url;
}
function cookiesFrom(headers) {
  if (typeof headers.getSetCookie === 'function') return headers.getSetCookie();
  // The separator after an Expires date is not followed by a cookie name and '='.
  return (headers.get('set-cookie') || '').split(/,(?=\s*[^;,=\s]+=[^;]*)/).filter(Boolean);
}
function rememberCookies(jar, url, headers) {
  const bucket = jar.get(url.origin) || new Map();
  for (const value of cookiesFrom(headers)) {
    const parts=value.split(';').map(p=>p.trim()); const pair=parts.shift(); const index=pair.indexOf('=');
    if(index<1) continue;
    const attributes=Object.fromEntries(parts.map(p=>{const i=p.indexOf('=');return i<0?[p.toLowerCase(),true]:[p.slice(0,i).toLowerCase(),p.slice(i+1)];}));
    const name=pair.slice(0,index); const path=typeof attributes.path==='string'?attributes.path:(url.pathname.slice(0,url.pathname.lastIndexOf('/')+1)||'/');
    const key=name+'|'+path;
    if(attributes.domain && String(attributes.domain).replace(/^\./,'').toLowerCase()!==url.hostname.toLowerCase()) continue;
    if(Number(attributes['max-age'])<=0 || (attributes.expires && Date.parse(attributes.expires)<Date.now())) bucket.delete(key);
    else bucket.set(key,{pair,path,secure:!!attributes.secure});
  }
  jar.set(url.origin,bucket);
}
function cookieHeader(jar,url){return [...(jar.get(url.origin)?.values()||[])].filter(c=>(url.pathname===c.path||url.pathname.startsWith(c.path.endsWith('/')?c.path:c.path+'/'))&&(!c.secure||url.protocol==='https:')).map(c=>c.pair).join('; ');}
function bridgeError(status,message) {return new Response(JSON.stringify({error:message}),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store','X-Plyxe-Source':'bridge','X-Plyxe-Version':'2'}});}
export default {
 async fetch(request, env = {}) {
  const requestURL = new URL(request.url), target=requestURL.searchParams.get('url');
  if(!target) return new Response('Puente Plyxe activo · versión 2',{headers:{'X-Plyxe-Version':'2','Cache-Control':'no-store'}});
  if(env.BRIDGE_KEY && request.headers.get('X-Plyxe-Bridge-Key')!==env.BRIDGE_KEY) return bridgeError(403,'Clave del puente incorrecta.');
  if(request.method==='OPTIONS') return new Response(null,{status:204,headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET, HEAD, OPTIONS','Access-Control-Allow-Headers':'Range','Access-Control-Max-Age':'600'}});
  if(!['GET','HEAD'].includes(request.method))return bridgeError(405,'Método no permitido.');
  let current;
  try {current=targetURL(target);}catch {return bridgeError(400,'Destino no válido.');}
  const jar=new Map(); const visited=new Set();
  try {
   for(let hops=0;hops<7;hops++) {
    if(visited.has(current.href))return bridgeError(502,'Bucle de redirecciones del proveedor.');
    visited.add(current.href);
    const headers=new Headers({'User-Agent':'VLC/3.0.18 LibVLC/3.0.18','Accept':'*/*','Accept-Encoding':'identity'});
    for(const name of ['Range','If-Range'])if(request.headers.has(name))headers.set(name,request.headers.get(name));
    const cookies=cookieHeader(jar,current);if(cookies)headers.set('Cookie',cookies);
    const response=await fetch(current.href,{method:request.method,headers,redirect:'manual',cache:'no-store'});
    rememberCookies(jar,current,response.headers);
    if([301,302,303,307,308].includes(response.status)&&response.headers.has('location')){
     const next=new URL(response.headers.get('location'),current);
     await response.body?.cancel();
     try{current=targetURL(next.href);}catch{return bridgeError(502,'El proveedor redirigió a un destino no permitido.');}
     continue;
    }
    const outgoing=new Headers();
    for(const name of ['Content-Type','Content-Length','Content-Range','Accept-Ranges','Content-Encoding','ETag','Last-Modified'])if(response.headers.has(name))outgoing.set(name,response.headers.get(name));
    outgoing.set('Cache-Control','no-store');outgoing.set('Access-Control-Allow-Origin','*');
    outgoing.set('Access-Control-Expose-Headers','Content-Range, Accept-Ranges, X-Plyxe-Source, X-Plyxe-Version');
    outgoing.set('X-Plyxe-Source','provider');outgoing.set('X-Plyxe-Version','2');outgoing.set('X-Plyxe-Redirects',String(hops));
    // PHP uses this as the base of relative HLS resources. Never expose it in the app UI.
    outgoing.set('X-Plyxe-Final-URL',encodeURIComponent(current.href));
    return new Response(request.method==='HEAD'?null:response.body,{status:response.status,headers:outgoing});
   }
   return bridgeError(502,'Demasiadas redirecciones del proveedor.');
  }catch{return bridgeError(502,'El Worker no pudo conectar con el destino del proveedor.');}
 }
};
