<?php
declare(strict_types=1);
require_once __DIR__ . '/common.php';
function data_dir(): string {
    $dir = getenv('PLYXE_DATA_DIR') ?: dirname(__DIR__, 2) . '/../.plyxe-' . substr(hash('sha256', dirname(__DIR__)), 0, 12);
    if (!is_dir($dir) && !@mkdir($dir, 0700, true)) fail(503, 'No se puede crear el almacenamiento privado. Configura PLYXE_DATA_DIR en una carpeta escribible fuera de la web.');
    return $dir;
}
function encode_private(mixed $data): string { return "<?php exit; ?>\n" . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR); }
function decode_private(string $text): mixed { return json_decode(substr($text, strlen("<?php exit; ?>\n")), true, 512, JSON_THROW_ON_ERROR); }
function initial_state(): array {
    return ['admin'=>['login'=>'admin','password'=>password_hash('admin',PASSWORD_DEFAULT),'version'=>1,'mustChange'=>true], 'users'=>[], 'leases'=>[], 'attempts'=>[], 'settings'=>['provider'=>['mode'=>'xtream','server'=>'','username'=>'','password'=>'','playlist'=>'','bridge'=>BRIDGE_URL], 'pin'=>password_hash('8080',PASSWORD_DEFAULT),'layout'=>[], 'revision'=>1]];
}
function state(callable $callback, bool $write = true): mixed {
    $dir=data_dir(); $lock=fopen($dir.'/state.lock','c'); if(!$lock || !flock($lock,LOCK_EX)) fail(503,'El almacenamiento está ocupado.');
    try {
        $file=$dir.'/state.php'; $new=!is_file($file);
        $db=$new?initial_state():decode_private(file_get_contents($file));
        $result=$callback($db);
        if($write || $new){$tmp=tempnam($dir,'state-');file_put_contents($tmp,encode_private($db));chmod($tmp,0600);if(!rename($tmp,$file))throw new RuntimeException('write');}
        return $result;
    } catch(Throwable $e) { fail(503,'No se pudo leer o guardar la configuración privada de Plyxe.'); }
    finally {flock($lock,LOCK_UN);fclose($lock);}
}
function clean_leases(array &$db): void {
    foreach($db['leases'] as $token=>$lease) if($lease['heartbeat']<time()-25) unset($db['leases'][$token]);
}
function public_user(array $user): array {return array_intersect_key($user,array_flip(['id','name','username','expires','maxDevices','active','profiles']));}
function actor(bool $admin=false): array {
    open_session(); $auth=$_SESSION['plyxe']??null; session_write_close();
    if(!$auth)fail(401,'Inicia sesión en Plyxe.');
    $result=state(function(&$db)use($auth){
        if($auth['role']==='admin')return $auth['version']===$db['admin']['version']?['role'=>'admin','id'=>'admin','mustChange'=>$db['admin']['mustChange']]:null;
        $u=$db['users'][$auth['id']]??null;
        if(!$u || !$u['active'] || $u['expires']<=time() || $auth['version']!==$u['version'])return null;
        return ['role'=>'user']+public_user($u);
    },false);
    if(!$result)fail(401,'Tu cuenta venció, fue desactivada o cambió de contraseña.');
    if($admin && $result['role']!=='admin')fail(403,'Acceso exclusivo de administración.');
    return $result;
}
function pin_valid(): bool {open_session();$until=$_SESSION['adult_until']??0;$grant=$_SESSION['adult_grant']??'';session_write_close();return $until>time() && hash_equals(app_settings()['pin'],$grant);}
function require_pin(bool $adult): void {if($adult&&!pin_valid())fail(423,'Introduce el PIN para contenido adulto.');}
function adult_name(string $text): bool {return (bool)preg_match('/adult|xxx|porn|er[oó]ti|\+18|18\+|🔞/iu',$text);}
function app_settings(): array {return state(fn(&$db)=>$db['settings'],false);}
function lease_valid(string $token, string $uid): bool {
    return state(function(&$db)use($token,$uid){$l=$db['leases'][$token]??null;$u=$db['users'][$uid]??null;return $l && $l['uid']===$uid && $l['heartbeat']>=time()-25 && $u && $u['active'] && $u['expires']>time() && $l['version']===$u['version'];},false);
}
function create_lease(string $uid,string $device,int $profile,string $url,string $format,bool $adult): string {
    return state(function(&$db)use($uid,$device,$profile,$url,$format,$adult){
        clean_leases($db);$u=$db['users'][$uid]??null;
        if(!$u || !$u['active'] || $u['expires']<=time())return '';
        foreach($db['leases'] as $t=>$l)if($l['uid']===$uid&&$l['device']===$device)unset($db['leases'][$t]);
        $owned=array_filter($db['leases'],fn($l)=>$l['uid']===$uid);uasort($owned,fn($a,$b)=>$a['started']<=>$b['started']);
        while(count($owned)>=$u['maxDevices']){$old=array_key_first($owned);unset($db['leases'][$old],$owned[$old]);}
        $token=bin2hex(random_bytes(24));$db['leases'][$token]=['uid'=>$uid,'version'=>$u['version'],'device'=>$device,'profile'=>$profile,'started'=>microtime(true),'heartbeat'=>time(),'adult'=>$adult,'format'=>$format,'resources'=>['root'=>$url]];return $token;
    });
}
function media_link(string $token,string $url): string {
    $key=substr(hash('sha256',$url),0,24);
    state(function(&$db)use($token,$url,$key){if(isset($db['leases'][$token]))$db['leases'][$token]['resources'][$key]=$url;});
    return '/api/media?lease='.rawurlencode($token).'&resource='.$key;
}
