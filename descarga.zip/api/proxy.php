<?php
require __DIR__ . '/common.php';
open_session();
$authorized = !empty($_SESSION['binding']) && ($_SESSION['expires'] ?? 0) >= time();
session_write_close();
if (!$authorized) fail(401, 'Conecta tu cuenta IPTV antes de reproducir.');
$url = $_GET['url'] ?? '';
if (!is_string($url) || strlen($url) > 12000 || $url === '') fail(400, 'URL parameter is required');
@set_time_limit(0);
$range = $_SERVER['HTTP_RANGE'] ?? '';
if ($range !== '' && !preg_match('/^bytes=\d*-\d*$/', $range)) fail(416, 'Rango no válido.');
for ($redirect = 0; $redirect < 6; $redirect++) {
    $curl = handle($url); $headers = []; $status = 0; $body = ''; $sent = false;
    $manifest = (bool)preg_match('/\.(m3u8|m3u)(?:\?|$)/i', $url);
    if ($range !== '') curl_setopt($curl, CURLOPT_HTTPHEADER, ['Range: ' . $range]);
    curl_setopt_array($curl, [CURLOPT_HEADERFUNCTION => function($c, $line) use (&$headers, &$status, &$manifest) {
        if (preg_match('~^HTTP/\S+ (\d+)~', $line, $match)) { $status = (int)$match[1]; $headers = []; }
        elseif (str_contains($line, ':')) { [$key, $value] = explode(':', $line, 2); $headers[strtolower(trim($key))] = trim($value); }
        if (stripos($headers['content-type'] ?? '', 'mpegurl') !== false) $manifest = true;
        return strlen($line);
    }, CURLOPT_WRITEFUNCTION => function($c, $chunk) use (&$headers, &$status, &$manifest, &$body, &$sent) {
        if ($status < 200 || $status >= 300) return strlen($chunk);
        if ($manifest) { if (strlen($body) + strlen($chunk) > 8 * 1024 * 1024) return 0; $body .= $chunk; }
        else {
            if (!$sent) {
                http_response_code($status); header('Content-Type: ' . ($headers['content-type'] ?? 'application/octet-stream')); header('Cache-Control: no-store'); header('X-Content-Type-Options: nosniff');
                foreach (['content-range','accept-ranges','content-length'] as $key) if (isset($headers[$key])) header($key . ': ' . $headers[$key]);
                while (ob_get_level()) ob_end_clean();
                $sent = true;
            }
            echo $chunk; flush();
            if (connection_aborted()) return 0;
        }
        return strlen($chunk);
    }]);
    $ok = curl_exec($curl); $info = curl_getinfo($curl); $code = curl_errno($curl); curl_close($curl);
    if ($ok === false) { if (!$sent) fail(502, transfer_error($code, $info)); exit; }
    if ($status >= 300 && $status < 400 && isset($headers['location'])) { $url = absolute_url($headers['location'], $url); continue; }
    if ($status < 200 || $status >= 300) fail($status >= 400 ? $status : 502, 'El proveedor no pudo entregar el contenido.');
    if ($manifest) {
        $rewrite = fn($ref) => '/api/proxy?url=' . rawurlencode(absolute_url($ref, $url));
        $lines = explode("\n", $body);
        foreach ($lines as &$line) {
            $trimmed = trim($line);
            if ($trimmed === '') continue;
            if ($trimmed[0] === '#') $line = preg_replace_callback('/URI="([^"]+)"/', fn($m) => 'URI="' . $rewrite($m[1]) . '"', $line);
            else $line = $rewrite($trimmed);
        }
        header('Content-Type: application/vnd.apple.mpegurl'); header('Cache-Control: no-store'); echo implode("\n", $lines);
    }
    exit;
}
fail(502, 'Demasiadas redirecciones del proveedor.');
