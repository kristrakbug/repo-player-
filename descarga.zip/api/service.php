<?php
require_once __DIR__ . '/store.php';
function provider_request(string $action='',string $id=''): mixed {
    $s=app_settings();$p=$s['provider'];$GLOBALS['plyxe_bridge']=$p['bridge'];$GLOBALS['plyxe_bridge_key']=$p['bridgeKey']??'';
    if(!$p['server']||!$p['username']||!$p['password'])fail(503,'El administrador debe configurar el proveedor IPTV.');
    $args=['username'=>$p['username'],'password'=>$p['password']];if($action)$args['action']=$action;if($id)$args['series_id']=$id;
    return fetch_json(rtrim($p['server'],'/').'/player_api.php?'.http_build_query($args,'','&',PHP_QUERY_RFC3986));
}
function provider_text(string $url): string {
    $p = app_settings()['provider'];
    $GLOBALS['plyxe_bridge'] = $p['bridge'];
    $GLOBALS['plyxe_bridge_key'] = $p['bridgeKey'] ?? '';
    $limit = 100 * 1024 * 1024;
    for ($redirect = 0; $redirect < 6; $redirect++) {
        $curl = handle($url);
        $body = ''; $location = ''; $tooLarge = false; $received = 0;
        curl_setopt_array($curl, [
            CURLOPT_TIMEOUT => 90,
            CURLOPT_HEADERFUNCTION => function($c, $line) use (&$location, &$tooLarge, $limit) {
                if (preg_match('~^HTTP/\S+ \d+~', $line)) $location = '';
                if (stripos($line, 'Location:') === 0) $location = trim(substr($line, 9));
                if (stripos($line, 'Content-Length:') === 0 && (float)trim(substr($line, 15)) > $limit) {
                    $tooLarge = true;
                    return 0;
                }
                return strlen($line);
            },
            CURLOPT_WRITEFUNCTION => function($c, $chunk) use (&$body, &$tooLarge, &$received, $limit) {
                $length = strlen($chunk);
                if ($received + $length > $limit) { $tooLarge = true; return 0; }
                $body .= $chunk; $received += $length;
                return $length;
            }
        ]);
        $ok = curl_exec($curl);
        $info = curl_getinfo($curl);
        $code = curl_errno($curl);
        $info['curl_detail'] = safe_curl_detail(curl_error($curl), $url);
        curl_close($curl);
        if ($ok === false) fail(502, transfer_error($code, $info, $tooLarge));
        $status = (int)$info['http_code'];
        if ($status >= 300 && $status < 400 && $location !== '') {
            $url = absolute_url($location, $url);
            continue;
        }
        if ($status !== 200) fail(502, 'El proveedor o el puente devolvió HTTP ' . $status . ' al descargar la lista M3U.');
        return $body;
    }
    fail(502, 'Demasiadas redirecciones del proveedor.');
}
function cached(string $key, callable $load, int $ttl = 300): mixed {
    $file = data_dir() . '/cache-' . hash('sha256', $key) . '.php';
    // TV, movies and series may request the same M3U concurrently. Download once.
    $lock = fopen($file . '.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX)) fail(503, 'No se pudo bloquear la caché del catálogo.');
    try {
        clearstatcache(true, $file);
        if (is_file($file) && filemtime($file) > time() - $ttl) {
            try { return decode_private(file_get_contents($file)); } catch (Throwable $e) {}
        }
        $data = $load();
        $tmp = tempnam(data_dir(), 'cache-');
        if ($tmp === false || file_put_contents($tmp, encode_private($data)) === false) {
            if ($tmp !== false) @unlink($tmp);
            fail(503, 'No se pudo guardar la caché del catálogo. Revisa espacio y permisos del almacenamiento privado.');
        }
        chmod($tmp, 0600);
        if (!rename($tmp, $file)) { @unlink($tmp); fail(503, 'No se pudo actualizar la caché del catálogo.'); }
        return $data;
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}
function playlist_lines(string $text): Generator {
    // Avoid duplicating a large playlist into an array of every line.
    $offset = 0; $length = strlen($text);
    while ($offset < $length) {
        $end = strpos($text, "\n", $offset);
        if ($end === false) { yield substr($text, $offset); break; }
        yield substr($text, $offset, $end - $offset);
        $offset = $end + 1;
    }
}
function raw_catalog(string $kind): array {
    $s=app_settings();$p=$s['provider'];
    return cached('catalog-'.$kind.'-'.hash('sha256',json_encode($p)),function()use($kind,$p){
        if($p['mode']==='m3u')return m3u_catalog()[$kind];
        $prefix=$kind==='movie'?'vod':$kind;
        $categories=json_decode(json_encode(provider_request('get_'.$prefix.'_categories')),true);
        $rows=json_decode(json_encode(provider_request($kind==='series'?'get_series':'get_'.$prefix.'_streams')),true);
        if(!is_array($rows)||!array_is_list($rows))fail(502,'El proveedor devolvió un catálogo no válido.');
        if(!is_array($categories)||!array_is_list($categories))fail(502,'El proveedor devolvió categorías no válidas.');
        $names=[];foreach($categories as $c)$names[(string)$c['category_id']]=(string)$c['category_name'];
        $items=[];foreach($rows as $r){$id=$r['stream_id']??$r['series_id']??null;if($id===null)continue;$category=(string)($r['category_id']??'');$extension=preg_match('/^[a-z0-9]+$/i',$r['container_extension']??'')?$r['container_extension']:'mp4';$items[]=['id'=>(string)$id,'name'=>(string)($r['name']??'Sin título'),'kind'=>$kind,'category'=>$category,'image'=>$r['stream_icon']??$r['cover']??'','backdrop'=>is_array($r['backdrop_path']??null)?($r['backdrop_path'][0]??''):($r['backdrop_path']??''),'plot'=>$r['plot']??'','year'=>(string)($r['year']??''),'rating'=>!empty($r['rating'])?(string)$r['rating']:null,'extension'=>$extension,'source'=>$r['direct_source']??'','adult'=>adult_name(($names[$category]??'').' '.($r['name']??''))];}
        return ['items'=>$items,'categories'=>is_array($categories)?$categories:[]];
    });
}
function m3u_catalog(): array {
    $p=app_settings()['provider'];if(!$p['playlist'])fail(503,'Configura una URL de lista M3U en administración.');
    return cached('m3u-'.hash('sha256',$p['playlist']),function()use($p){
        $text=provider_text($p['playlist']);$out=['live'=>['items'=>[],'categories'=>[]],'movie'=>['items'=>[],'categories'=>[]],'series'=>['items'=>[],'categories'=>[]]];$groups=[];$current=[];
        if(str_contains($text,'#EXT-X-')){$out['live']['items'][]=['id'=>'hls','name'=>'Plyxe TV','kind'=>'live','category'=>'live','image'=>'','source'=>$p['playlist'],'extension'=>'m3u8','adult'=>false];$out['live']['categories'][]=['category_id'=>'live','category_name'=>'TV'];return $out;}
        foreach(playlist_lines($text)as $line){$line=trim($line);if(str_starts_with($line,'#EXTINF:')){preg_match('/,(.*)$/',$line,$name);preg_match('/group-title="([^"]*)"/i',$line,$group);preg_match('/tvg-logo="([^"]*)"/i',$line,$image);$current=['name'=>$name[1]??'Sin título','group'=>$group[1]??'General','image'=>$image[1]??''];}elseif($line!==''&&!str_starts_with($line,'#')&&$current){$source=absolute_url($line,$p['playlist']);$kind=preg_match('/pel[ií]cula|movie|vod|cine/iu',$current['group'])?'movie':(preg_match('/serie|temporada/iu',$current['group'])?'series':'live');$category=substr(hash('sha256',$current['group']),0,12);$groups[$kind][$category]=$current['group'];$id=substr(hash('sha256',$source),0,20);$ext=strtolower(pathinfo(parse_url($source,PHP_URL_PATH)??'',PATHINFO_EXTENSION));$item=['id'=>$id,'name'=>$current['name'],'kind'=>$kind,'category'=>$category,'image'=>$current['image'],'source'=>$source,'extension'=>$ext?:'mp4','adult'=>adult_name($current['group'].' '.$current['name'])];if($kind==='series'){preg_match('/^(.*?)\s*S(\d+)\s*E(\d+)/i',$item['name'],$parts);$show=trim($parts[1]??$item['name']);$seriesId=substr(hash('sha256',$category.$show),0,20);if(!isset($out['series']['items'][$seriesId]))$out['series']['items'][$seriesId]=array_merge($item,['id'=>$seriesId,'name'=>$show,'episodes'=>[]]);$out['series']['items'][$seriesId]['episodes'][(string)(int)($parts[2]??1)][]=['id'=>$id,'title'=>$item['name'],'source'=>$source,'container_extension'=>$item['extension']];}else $out[$kind]['items'][]=$item;$current=[];}}
        foreach($out as $kind=>&$section){$section['items']=array_values($section['items']);foreach($groups[$kind]??[]as $id=>$name)$section['categories'][]=['category_id'=>$id,'category_name'=>$name];}return $out;
    });
}
function catalog_for(string $kind,bool $private=false): array {
    $raw=raw_catalog($kind);$layout=app_settings()['layout'][$kind]??[];$order=array_flip(array_map('strval',$layout['order']??[]));
    foreach($raw['categories']as &$c){$id=(string)$c['category_id'];$c['adult']=adult_name($c['category_name'])||in_array($id,$layout['adult']??[],true);$c['category_name']=$layout['titles'][$id]??$c['category_name'];}unset($c);
    usort($raw['categories'],fn($a,$b)=>($order[(string)$a['category_id']]??999999)<=>($order[(string)$b['category_id']]??999999));
    $adult=[];foreach($raw['categories']as $c)$adult[(string)$c['category_id']]=$c['adult'];
    $items=[];foreach($raw['categories']as $c){$id=(string)$c['category_id'];$rows=array_values(array_filter($raw['items'],fn($i)=>$i['category']===$id));if(in_array($id,$layout['reverse']??[],true))$rows=array_reverse($rows);foreach($rows as $r)$items[]=$r;}
    foreach($raw['items']as $r)if(!array_key_exists($r['category'],$adult))$items[]=$r;
    $featured=$layout['featured']??'';$marked=false;
    foreach($items as &$item){$item['adult']=$item['adult']||($adult[$item['category']]??false);$item['locked']=$item['adult'];$item['featured']=!$marked&&$featured!==''&&$item['category']===$featured&&!$item['adult'];if($item['featured'])$marked=true;if(!$private)unset($item['source'],$item['episodes']);}unset($item);
    return ['items'=>$items,'categories'=>$raw['categories']];
}
function find_item(string $kind,string $id): array {foreach(catalog_for($kind,true)['items']as $item)if($item['id']===$id)return $item;fail(404,'Este título ya no está en el catálogo.');}
function episodes_for(array $item): array {
    if(isset($item['episodes']))return $item['episodes'];
    $p=app_settings()['provider'];$data=cached('episodes-'.$item['id'].'-'.hash('sha256',json_encode($p)),fn()=>json_decode(json_encode(provider_request('get_series_info',$item['id'])),true));
    $groups=[];foreach($data['episodes']??[]as $season=>$rows){if(!is_array($rows))continue;foreach($rows as $r){if(!isset($r['id']))continue;$r['source']=$r['direct_source']??'';unset($r['direct_source']);$groups[(string)$season][]=$r;}}return $groups;
}
function source_for(string $kind,array $item): string {
    if(!empty($item['source'])&&preg_match('~^https?://~i',$item['source']))return $item['source'];
    $p=app_settings()['provider'];$ext=$kind==='live'?'m3u8':($item['container_extension']??$item['extension']??'mp4');if(!preg_match('/^[a-z0-9]+$/i',$ext))$ext='mp4';return rtrim($p['server'],'/').'/'.$kind.'/'.rawurlencode($p['username']).'/'.rawurlencode($p['password']).'/'.rawurlencode((string)$item['id']).'.'.$ext;
}
