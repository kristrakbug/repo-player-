<?php
require_once __DIR__ . '/store.php';
function provider_request(string $action='',string $id=''): mixed {
    $s=app_settings();$p=$s['provider'];$GLOBALS['plyxe_bridge']=$p['bridge'];$GLOBALS['plyxe_bridge_key']=$p['bridgeKey']??'';
    if(!$p['server']||!$p['username']||!$p['password'])fail(503,'El administrador debe configurar el proveedor IPTV.');
    $args=['username'=>$p['username'],'password'=>$p['password']];if($action)$args['action']=$action;if($id)$args['series_id']=$id;
    return fetch_json(rtrim($p['server'],'/').'/player_api.php?'.http_build_query($args,'','&',PHP_QUERY_RFC3986));
}
function provider_text(string $url): string {
    $p=app_settings()['provider'];$GLOBALS['plyxe_bridge']=$p['bridge'];$GLOBALS['plyxe_bridge_key']=$p['bridgeKey']??'';
    for($i=0;$i<6;$i++){$c=handle($url);$body='';$location='';curl_setopt_array($c,[CURLOPT_TIMEOUT=>40,CURLOPT_HEADERFUNCTION=>function($c,$line)use(&$location){if(stripos($line,'Location:')===0)$location=trim(substr($line,9));return strlen($line);},CURLOPT_WRITEFUNCTION=>function($c,$chunk)use(&$body){if(strlen($body)+strlen($chunk)>25*1024*1024)return 0;$body.=$chunk;return strlen($chunk);}]);$ok=curl_exec($c);$info=curl_getinfo($c);$code=curl_errno($c);curl_close($c);if(!$ok)fail(502,transfer_error($code,$info));if($info['http_code']>=300&&$info['http_code']<400&&$location){$url=absolute_url($location,$url);continue;}if($info['http_code']!==200)fail(502,'El proveedor rechazó la lista M3U.');return $body;}fail(502,'Demasiadas redirecciones.');
}
function cached(string $key,callable $load,int $ttl=300): mixed {
    $file=data_dir().'/cache-'.hash('sha256',$key).'.php';
    if(is_file($file)&&filemtime($file)>time()-$ttl){try{return decode_private(file_get_contents($file));}catch(Throwable $e){}}
    $data=$load();$tmp=tempnam(data_dir(),'cache-');file_put_contents($tmp,encode_private($data));chmod($tmp,0600);rename($tmp,$file);return $data;
}
function raw_catalog(string $kind): array {
    $s=app_settings();$p=$s['provider'];
    return cached('catalog-'.$kind.'-'.hash('sha256',json_encode($p)),function()use($kind,$p){
        if($p['mode']==='m3u')return m3u_catalog()[$kind];
        $prefix=$kind==='movie'?'vod':$kind;
        $categories=json_decode(json_encode(provider_request('get_'.$prefix.'_categories')),true);
        $rows=json_decode(json_encode(provider_request($kind==='series'?'get_series':'get_'.$prefix.'_streams')),true);
        if(!is_array($rows)||!array_is_list($rows))fail(502,'El proveedor devolvió un catálogo no válido.');
        if(!is_array($categories)||!array_is_list($categories))fail(502,'El proveedor devolvió categorías no válidas.');
        $names=[];foreach($categories as $c)$names[(string)$c['category_id']]=(string)$c['category_name'];
        $items=[];foreach($rows as $r){$id=$r['stream_id']??$r['series_id']??null;if($id===null)continue;$category=(string)($r['category_id']??'');$extension=preg_match('/^[a-z0-9]+$/i',$r['container_extension']??'')?$r['container_extension']:'mp4';$items[]=['id'=>(string)$id,'name'=>(string)($r['name']??'Sin título'),'kind'=>$kind,'category'=>$category,'image'=>$r['stream_icon']??$r['cover']??'','backdrop'=>is_array($r['backdrop_path']??null)?($r['backdrop_path'][0]??''):($r['backdrop_path']??''),'plot'=>$r['plot']??'','year'=>(string)($r['year']??''),'rating'=>!empty($r['rating'])?(string)$r['rating']:null,'extension'=>$extension,'source'=>$r['direct_source']??'','adult'=>adult_name(($names[$category]??'').' '.($r['name']??''))];}
        return ['items'=>$items,'categories'=>is_array($categories)?$categories:[]];
    });
}
function m3u_catalog(): array {
    $p=app_settings()['provider'];if(!$p['playlist'])fail(503,'Configura una URL de lista M3U en administración.');
    return cached('m3u-'.hash('sha256',$p['playlist']),function()use($p){
        $text=provider_text($p['playlist']);$out=['live'=>['items'=>[],'categories'=>[]],'movie'=>['items'=>[],'categories'=>[]],'series'=>['items'=>[],'categories'=>[]]];$groups=[];$current=[];
        if(str_contains($text,'#EXT-X-')){$out['live']['items'][]=['id'=>'hls','name'=>'Plyxe TV','kind'=>'live','category'=>'live','image'=>'','source'=>$p['playlist'],'extension'=>'m3u8','adult'=>false];$out['live']['categories'][]=['category_id'=>'live','category_name'=>'TV'];return $out;}
        foreach(preg_split('/\r?\n/',$text)as $line){$line=trim($line);if(str_starts_with($line,'#EXTINF:')){preg_match('/,(.*)$/',$line,$name);preg_match('/group-title="([^"]*)"/i',$line,$group);preg_match('/tvg-logo="([^"]*)"/i',$line,$image);$current=['name'=>$name[1]??'Sin título','group'=>$group[1]??'General','image'=>$image[1]??''];}elseif($line!==''&&!str_starts_with($line,'#')&&$current){$source=absolute_url($line,$p['playlist']);$kind=preg_match('/pel[ií]cula|movie|vod|cine/iu',$current['group'])?'movie':(preg_match('/serie|temporada/iu',$current['group'])?'series':'live');$category=substr(hash('sha256',$current['group']),0,12);$groups[$kind][$category]=$current['group'];$id=substr(hash('sha256',$source),0,20);$ext=strtolower(pathinfo(parse_url($source,PHP_URL_PATH)??'',PATHINFO_EXTENSION));$item=['id'=>$id,'name'=>$current['name'],'kind'=>$kind,'category'=>$category,'image'=>$current['image'],'source'=>$source,'extension'=>$ext?:'mp4','adult'=>adult_name($current['group'].' '.$current['name'])];if($kind==='series'){preg_match('/^(.*?)\s*S(\d+)\s*E(\d+)/i',$item['name'],$parts);$show=trim($parts[1]??$item['name']);$seriesId=substr(hash('sha256',$category.$show),0,20);if(!isset($out['series']['items'][$seriesId]))$out['series']['items'][$seriesId]=array_merge($item,['id'=>$seriesId,'name'=>$show,'episodes'=>[]]);$out['series']['items'][$seriesId]['episodes'][(string)(int)($parts[2]??1)][]=['id'=>$id,'title'=>$item['name'],'source'=>$source,'container_extension'=>$item['extension']];}else $out[$kind]['items'][]=$item;$current=[];}}
        foreach($out as $kind=>&$section){$section['items']=array_values($section['items']);foreach($groups[$kind]??[]as $id=>$name)$section['categories'][]=['category_id'=>$id,'category_name'=>$name];}return $out;
    });
}
function catalog_for(string $kind,bool $private=false): array {
    $raw=raw_catalog($kind);$layout=app_settings()['layout'][$kind]??[];$order=array_flip(array_map('strval',$layout['order']??[]));
    foreach($raw['categories']as &$c){$id=(string)$c['category_id'];$c['adult']=adult_name($c['category_name'])||in_array($id,$layout['adult']??[],true);$c['category_name']=$layout['titles'][$id]??$c['category_name'];}unset($c);
    usort($raw['categories'],fn($a,$b)=>($order[(string)$a['category_id']]??999999)<=>($order[(string)$b['category_id']]??999999));
    $adult=[];foreach($raw['categories']as $c)$adult[(string)$c['category_id']]=$c['adult'];
    $items=[];foreach($raw['categories']as $c){$id=(string)$c['category_id'];$rows=array_values(array_filter($raw['items'],fn($i)=>$i['category']===$id));if(in_array($id,$layout['reverse']??[],true))$rows=array_reverse($rows);foreach($rows as $r)$items[]=$r;}
    foreach($raw['items']as $r)if(!array_key_exists($r['category'],$adult))$items[]=$r;
    $featured=$layout['featured']??'';$marked=false;
    foreach($items as &$item){$item['adult']=$item['adult']||($adult[$item['category']]??false);$item['locked']=$item['adult'];$item['featured']=!$marked&&$featured!==''&&$item['category']===$featured&&!$item['adult'];if($item['featured'])$marked=true;if(!$private)unset($item['source'],$item['episodes']);}unset($item);
    return ['items'=>$items,'categories'=>$raw['categories']];
}
function find_item(string $kind,string $id): array {foreach(catalog_for($kind,true)['items']as $item)if($item['id']===$id)return $item;fail(404,'Este título ya no está en el catálogo.');}
function episodes_for(array $item): array {
    if(isset($item['episodes']))return $item['episodes'];
    $p=app_settings()['provider'];$data=cached('episodes-'.$item['id'].'-'.hash('sha256',json_encode($p)),fn()=>json_decode(json_encode(provider_request('get_series_info',$item['id'])),true));
    $groups=[];foreach($data['episodes']??[]as $season=>$rows){if(!is_array($rows))continue;foreach($rows as $r){if(!isset($r['id']))continue;$r['source']=$r['direct_source']??'';unset($r['direct_source']);$groups[(string)$season][]=$r;}}return $groups;
}
function source_for(string $kind,array $item): string {
    if(!empty($item['source'])&&preg_match('~^https?://~i',$item['source']))return $item['source'];
    $p=app_settings()['provider'];$ext=$kind==='live'?'m3u8':($item['container_extension']??$item['extension']??'mp4');if(!preg_match('/^[a-z0-9]+$/i',$ext))$ext='mp4';return rtrim($p['server'],'/').'/'.$kind.'/'.rawurlencode($p['username']).'/'.rawurlencode($p['password']).'/'.rawurlencode((string)$item['id']).'.'.$ext;
}
