<?php
declare(strict_types=1);
ini_set('display_errors', '0');
// Preserves the bridge configured for this deployment.
const BRIDGE_URL = 'https://puente-iptv.univedson1.workers.dev';
function fail(int $status, string $message): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}
if (!extension_loaded('curl')) fail(503, 'Activa la extensión cURL de PHP en cPanel.');
function open_session(): void {
    session_start(['cookie_httponly' => true, 'cookie_samesite' => 'Lax', 'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'use_strict_mode' => true]);
}
function validate_url(string $url): array {
    $parts = parse_url($url);
    if (!$parts || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true) || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])) fail(400, 'La URL del servidor no es válida.');
    $host = trim($parts['host'], '[]');
    if (filter_var($host, FILTER_VALIDATE_IP)) $ips = [$host];
    else {
        $records = dns_get_record($host, DNS_A | DNS_AAAA);
        $ips = array_values(array_filter(array_map(fn($r) => $r['ip'] ?? $r['ipv6'] ?? null, $records ?: [])));
    }
    if (!$ips) fail(502, 'No se pudo resolver el dominio del proveedor IPTV.');
    foreach ($ips as $ip) if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) fail(403, 'El proveedor debe tener una dirección pública de Internet.');
    $port = $parts['port'] ?? ($parts['scheme'] === 'https' ? 443 : 80);
    return [$host, $port, $ips];
}
function absolute_url(string $reference, string $base): string {
    if (preg_match('~^[a-z][a-z0-9+.-]*:~i', $reference)) return $reference;
    $b = parse_url($base);
    if (str_starts_with($reference, '//')) return $b['scheme'] . ':' . $reference;
    $origin = $b['scheme'] . '://' . $b['host'] . (isset($b['port']) ? ':' . $b['port'] : '');
    if ($reference === '') return $base;
    if ($reference[0] === '?') return $origin . ($b['path'] ?? '/') . $reference;
    $r = parse_url($reference);
    $path = $r['path'] ?? '';
    if (!str_starts_with($path, '/')) $path = preg_replace('~/[^/]*$~', '/', $b['path'] ?? '/') . $path;
    $segments = [];
    foreach (explode('/', $path) as $segment) {
        if ($segment === '..') array_pop($segments);
        elseif ($segment !== '' && $segment !== '.') $segments[] = $segment;
    }
    return $origin . '/' . implode('/', $segments) . (str_ends_with($path, '/') ? '/' : '') . (isset($r['query']) ? '?' . $r['query'] : '') . (isset($r['fragment']) ? '#' . $r['fragment'] : '');
}
function transfer_error(int $code, array $info = [], bool $tooLarge = false): string {
    if ($tooLarge) return 'El catálogo supera el límite de 100 MB del reproductor. [NP-SIZE]';
    $message = match ($code) {
        5 => 'El hosting no pudo resolver su proxy de salida. Pide al soporte que revise la red.',
        6 => 'No se pudo resolver el dominio del proveedor. Revisa la URL o el DNS del hosting.',
        7 => 'No se pudo abrir la conexión al proveedor. Comprueba el puerto y pide al hosting y al proveedor que revisen el acceso desde la IP del hosting.',
        28 => (($info['connect_time'] ?? 0) > 0)
            ? 'La conexión se abrió, pero el proveedor no completó la respuesta a tiempo. Reintenta o consulta con el proveedor.'
            : 'Se agotó el tiempo de espera al conectar. El proveedor puede estar caído o la conexión puede estar filtrada por el hosting o el proveedor.',
        35 => 'Falló la negociación HTTPS con el proveedor. Consulta con el proveedor y el soporte del hosting.',
        52 => 'El proveedor cerró la conexión sin devolver una respuesta. Consulta si permite conexiones desde tu hosting.',
        55, 56 => 'La conexión con el proveedor se interrumpió durante la transferencia. Reintenta y, si persiste, consulta con el hosting y el proveedor.',
        60 => 'No se pudo verificar el certificado HTTPS del proveedor. Pide al proveedor y al hosting que revisen el certificado y las autoridades de confianza.',
        77 => 'El hosting no puede leer sus certificados de confianza. Pide al soporte que revise la configuración de cURL y CA.',
        default => 'No se pudo completar la solicitud al proveedor. Facilita este código al soporte del hosting.',
    };
    return $message . ' [NP-CURL-' . $code . ']';
}
function transport_url(string $url): string {
    return BRIDGE_URL !== '' ? rtrim(BRIDGE_URL, '/') . '/?url=' . rawurlencode($url) : $url;
}
function handle(string $url) {
    $target = validate_url($url);
    // Use the same transport for catalogs, media, and every redirect, including
    // upstream CDN URLs on ports 80 and 443. Each target is still validated.
    $requestUrl = transport_url($url);
    [$host, $port, $ips] = BRIDGE_URL !== '' ? validate_url($requestUrl) : $target;
    $curl = curl_init($requestUrl);
    $options = [CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS, CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_USERAGENT => 'VLC/3.0.18 LibVLC/3.0.18'];
    if (!filter_var($host, FILTER_VALIDATE_IP)) {
        $addresses = array_map(fn($ip) => str_contains($ip, ':') ? "[$ip]" : $ip, $ips);
        if (curl_version()['version_number'] < 0x073b00) $addresses = [$addresses[0]];
        $options[CURLOPT_RESOLVE] = ["$host:$port:" . implode(',', $addresses)];
    }
    curl_setopt_array($curl, $options);
    return $curl;
}
function fetch_json(string $url): mixed {
    for ($redirect = 0; $redirect < 6; $redirect++) {
        $curl = handle($url); $body = ''; $location = ''; $tooLarge = false;
        curl_setopt_array($curl, [CURLOPT_TIMEOUT => 40, CURLOPT_HEADERFUNCTION => function($c, $line) use (&$location) { if (stripos($line, 'Location:') === 0) $location = trim(substr($line,9)); return strlen($line); }, CURLOPT_WRITEFUNCTION => function($c, $chunk) use (&$body, &$tooLarge) { if (strlen($body) + strlen($chunk) > 100 * 1024 * 1024) { $tooLarge = true; return 0; } $body .= $chunk; return strlen($chunk); }]);
        $ok = curl_exec($curl); $info = curl_getinfo($curl); $code = curl_errno($curl); $status = $info['http_code']; curl_close($curl);
        if ($ok === false) fail(502, transfer_error($code, $info, $tooLarge));
        if ($status >= 300 && $status < 400 && $location !== '') { $url = absolute_url($location, $url); continue; }
        if ($status === 401 || $status === 403) fail(401, 'El proveedor rechazó el acceso. Revisa usuario y contraseña.');
        if ($status < 200 || $status >= 300) fail(502, 'El proveedor devolvió un error al cargar el catálogo.');
        $data = json_decode($body);
        if (json_last_error() !== JSON_ERROR_NONE || (!is_object($data) && !is_array($data))) fail(502, 'El servidor no devolvió una respuesta Xtream Codes válida.');
        return $data;
    }
    fail(502, 'Demasiadas redirecciones del proveedor.');
}
