<?php
declare(strict_types=1);
ini_set('display_errors', '0');
function fail(int $status, string $message): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}
if (!extension_loaded('curl')) fail(503, 'Activa la extensión cURL de PHP en cPanel.');
function open_session(): void {
    session_start(['cookie_httponly' => true, 'cookie_samesite' => 'Lax', 'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'use_strict_mode' => true]);
}
function validate_url(string $url): array {
    $parts = parse_url($url);
    if (!$parts || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true) || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])) fail(400, 'La URL del servidor no es válida.');
    $host = trim($parts['host'], '[]');
    if (filter_var($host, FILTER_VALIDATE_IP)) $ips = [$host];
    else {
        $records = dns_get_record($host, DNS_A | DNS_AAAA);
        $ips = array_values(array_filter(array_map(fn($r) => $r['ip'] ?? $r['ipv6'] ?? null, $records ?: [])));
    }
    if (!$ips) fail(502, 'No se pudo resolver el dominio del proveedor IPTV.');
    foreach ($ips as $ip) if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) fail(403, 'El proveedor debe tener una dirección pública de Internet.');
    $port = $parts['port'] ?? ($parts['scheme'] === 'https' ? 443 : 80);
    return [$host, $port, $ips[0]];
}
function absolute_url(string $reference, string $base): string {
    if (preg_match('~^[a-z][a-z0-9+.-]*:~i', $reference)) return $reference;
    $b = parse_url($base);
    if (str_starts_with($reference, '//')) return $b['scheme'] . ':' . $reference;
    $origin = $b['scheme'] . '://' . $b['host'] . (isset($b['port']) ? ':' . $b['port'] : '');
    if ($reference === '') return $base;
    if ($reference[0] === '?') return $origin . ($b['path'] ?? '/') . $reference;
    $r = parse_url($reference);
    $path = $r['path'] ?? '';
    if (!str_starts_with($path, '/')) $path = preg_replace('~/[^/]*$~', '/', $b['path'] ?? '/') . $path;
    $segments = [];
    foreach (explode('/', $path) as $segment) {
        if ($segment === '..') array_pop($segments);
        elseif ($segment !== '' && $segment !== '.') $segments[] = $segment;
    }
    return $origin . '/' . implode('/', $segments) . (str_ends_with($path, '/') ? '/' : '') . (isset($r['query']) ? '?' . $r['query'] : '') . (isset($r['fragment']) ? '#' . $r['fragment'] : '');
}
function handle(string $url) {
    [$host, $port, $ip] = validate_url($url);
    $curl = curl_init($url);
    curl_setopt_array($curl, [CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS, CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_USERAGENT => 'NightPlay/1.0', CURLOPT_RESOLVE => ["$host:$port:" . (str_contains($ip, ':') ? "[$ip]" : $ip)]]);
    return $curl;
}
function fetch_json(string $url): mixed {
    for ($redirect = 0; $redirect < 6; $redirect++) {
        $curl = handle($url); $body = ''; $location = '';
        curl_setopt_array($curl, [CURLOPT_TIMEOUT => 40, CURLOPT_HEADERFUNCTION => function($c, $line) use (&$location) { if (stripos($line, 'Location:') === 0) $location = trim(substr($line,9)); return strlen($line); }, CURLOPT_WRITEFUNCTION => function($c, $chunk) use (&$body) { if (strlen($body) + strlen($chunk) > 100 * 1024 * 1024) return 0; $body .= $chunk; return strlen($chunk); }]);
        $ok = curl_exec($curl); $status = curl_getinfo($curl, CURLINFO_RESPONSE_CODE); curl_close($curl);
        if ($ok === false) fail(502, 'No se pudo contactar con el proveedor. Comprueba la URL y las conexiones salientes del hosting.');
        if ($status >= 300 && $status < 400 && $location !== '') { $url = absolute_url($location, $url); continue; }
        if ($status === 401 || $status === 403) fail(401, 'El proveedor rechazó el acceso. Revisa usuario y contraseña.');
        if ($status < 200 || $status >= 300) fail(502, 'El proveedor devolvió un error al cargar el catálogo.');
        $data = json_decode($body);
        if (json_last_error() !== JSON_ERROR_NONE || (!is_object($data) && !is_array($data))) fail(502, 'El servidor no devolvió una respuesta Xtream Codes válida.');
        return $data;
    }
    fail(502, 'Demasiadas redirecciones del proveedor.');
}
