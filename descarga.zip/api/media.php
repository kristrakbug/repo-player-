<?php
require_once __DIR__ . '/service.php';
$who=actor();
$token=(string)($_GET['lease']??'');
if(!lease_valid($token,$who['id']))fail(409,'La reproducción fue cerrada o la cuenta venció.');
$resource=(string)($_GET['resource']??'root');
$url=state(fn(&$db)=>$db['leases'][$token]['resources'][$resource]??null,false);
if(!$url)fail(404,'Recurso de reproducción no encontrado.');
$settings=app_settings();$GLOBALS['plyxe_bridge']=$settings['provider']['bridge'];$GLOBALS['plyxe_bridge_key']=$settings['provider']['bridgeKey']??'';
$lastCheck=0;
@set_time_limit(0);
$range = $_SERVER['HTTP_RANGE'] ?? '';
if ($range !== '' && !preg_match('/^bytes=\d*-\d*$/', $range)) fail(416, 'Rango no válido.');
for ($redirect = 0; $redirect < 6; $redirect++) {
    $curl = handle($url);
    curl_setopt_array($curl,[CURLOPT_NOPROGRESS=>false,CURLOPT_XFERINFOFUNCTION=>function()use($token,$who,&$lastCheck){if(time()>$lastCheck){$lastCheck=time();if(!lease_valid($token,$who['id']))return 1;}return 0;}]);
    $headers = []; $status = 0; $body = ''; $sent = false;
    $manifest = (bool)preg_match('/\.(m3u8|m3u)(?:\?|$)/i', $url);
    if ($range !== '') curl_setopt($curl, CURLOPT_HTTPHEADER, array_merge(bridge_headers(), ['Range: ' . $range]));
    curl_setopt_array($curl, [CURLOPT_HEADERFUNCTION => function($c, $line) use (&$headers, &$status, &$manifest) {
        if (preg_match('~^HTTP/\S+ (\d+)~', $line, $match)) { $status = (int)$match[1]; $headers = []; }
        elseif (str_contains($line, ':')) { [$key, $value] = explode(':', $line, 2); $headers[strtolower(trim($key))] = trim($value); }
        if (stripos($headers['content-type'] ?? '', 'mpegurl') !== false) $manifest = true;
        return strlen($line);
    }, CURLOPT_WRITEFUNCTION => function($c, $chunk) use (&$headers, &$status, &$manifest, &$body, &$sent) {
        if ($status < 200 || $status >= 300) return strlen($chunk);
        if ($manifest) { if (strlen($body) + strlen($chunk) > 8 * 1024 * 1024) return 0; $body .= $chunk; }
        else {
            if (!$sent) {
                http_response_code($status); header('Content-Type: ' . ($headers['content-type'] ?? 'application/octet-stream')); header('Cache-Control: no-store'); header('X-Content-Type-Options: nosniff');
                foreach (['content-range','accept-ranges','content-length'] as $key) if (isset($headers[$key])) header($key . ': ' . $headers[$key]);
                while (ob_get_level()) ob_end_clean();
                $sent = true;
            }
            echo $chunk; flush();
            if (connection_aborted()) return 0;
        }
        return strlen($chunk);
    }]);
    $ok = curl_exec($curl); $info = curl_getinfo($curl); $code = curl_errno($curl); curl_close($curl);
    if ($ok === false) { if (!$sent) fail(502, transfer_error($code, $info)); exit; }
    if ($status >= 300 && $status < 400 && isset($headers['location'])) { $url = absolute_url($headers['location'], $url); continue; }
    if ($status < 200 || $status >= 300) {
        $origin = match ($headers['x-plyxe-source'] ?? '') { 'provider' => 'El destino solicitado por el Worker', 'bridge' => 'El propio Worker', default => 'El proveedor o el Worker anterior' };
        if (($headers['x-plyxe-source'] ?? '') === 'bridge') fail($status >= 400 ? $status : 502, $status === 403 ? 'El propio Worker rechazó la petición (HTTP 403). Revisa que BRIDGE_KEY coincida con la Clave del puente guardada en administración. [PLYXE-BRIDGE-403]' : 'El propio Worker no pudo completar la conexión o las redirecciones. [PLYXE-BRIDGE-' . $status . ']');
        $hops = isset($headers['x-plyxe-redirects']) ? ' Redirecciones: ' . (int)$headers['x-plyxe-redirects'] . '.' : '';
        fail($status >= 400 ? $status : 502, $origin . ' devolvió HTTP ' . $status . '.' . $hops . ' El reproductor no recibió el vídeo. Si la lista funciona desde tu red, solicita al proveedor autorización para la IP de salida del puente. [PLYXE-UPSTREAM-' . $status . ']');
    }
    if ($manifest) {
        if (($headers['x-plyxe-version'] ?? '') === '2' && isset($headers['x-plyxe-final-url'])) {
            $final = rawurldecode($headers['x-plyxe-final-url']);
            validate_url($final); $url = $final;
        }
        $rewrite = fn($ref) => media_link($token, absolute_url($ref, $url));
        $lines = explode("\n", $body);
        foreach ($lines as &$line) {
            $trimmed = trim($line);
            if ($trimmed === '') continue;
            if ($trimmed[0] === '#') $line = preg_replace_callback('/URI="([^"]+)"/', fn($m) => 'URI="' . $rewrite($m[1]) . '"', $line);
            else $line = $rewrite($trimmed);
        }
        header('Content-Type: application/vnd.apple.mpegurl'); header('Cache-Control: no-store'); echo implode("\n", $lines);
    }
    exit;
}
fail(502, 'Demasiadas redirecciones del proveedor.');
