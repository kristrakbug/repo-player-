<?php
require_once __DIR__.'/service.php';
function reply(mixed $value): never {header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($value,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
open_session();if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));$csrf=$_SESSION['csrf'];session_write_close();
if($_SERVER['REQUEST_METHOD']==='GET'){
    open_session();$auth=$_SESSION['plyxe']??null;session_write_close();$user=null;
    if($auth)$user=state(function(&$db)use($auth){if($auth['role']==='admin')return $auth['version']===$db['admin']['version']?['role'=>'admin','id'=>'admin','mustChange'=>$db['admin']['mustChange']]:null;$u=$db['users'][$auth['id']]??null;return $u&&$u['active']&&$u['expires']>time()&&$u['version']===$auth['version']?['role'=>'user']+public_user($u):null;},false);
    reply(['csrf'=>$csrf,'user'=>$user]);
}
if($_SERVER['REQUEST_METHOD']!=='POST')fail(405,'Método no permitido.');
if(!hash_equals($csrf,(string)($_SERVER['HTTP_X_PLYXE_CSRF']??'')))fail(403,'Recarga la página para renovar la sesión.');
$body=file_get_contents('php://input',false,null,0,262145);if(strlen($body)>262144)fail(413,'Solicitud demasiado grande.');$in=json_decode($body,true);if(!is_array($in))fail(400,'Solicitud no válida.');$action=$in['action']??'';
if($action==='login'){
    $login=trim((string)($in['username']??''));$password=(string)($in['password']??'');$admin=($in['admin']??false)===true;$ip=hash('sha256',($_SERVER['REMOTE_ADDR']??'').($admin?'admin':strtolower($login)));
    $result=state(function(&$db)use($login,$password,$admin,$ip){
        foreach($db['attempts']as $k=>$v)if($v['until']<time())unset($db['attempts'][$k]);
        $a=$db['attempts'][$ip]??['count'=>0,'until'=>time()+900];if($a['count']>=8)return ['blocked'=>true];
        $u=null;if($admin){if(strcasecmp($login,$db['admin']['login'])===0&&password_verify($password,$db['admin']['password']))$u=['role'=>'admin','id'=>'admin','version'=>$db['admin']['version'],'mustChange'=>$db['admin']['mustChange']];}
        else foreach($db['users']as $row)if(strcasecmp($row['username'],$login)===0&&password_verify($password,$row['password'])&&$row['active']&&$row['expires']>time()){$u=['role'=>'user','version'=>$row['version']]+public_user($row);break;}
        if(!$u){$a['count']++;$db['attempts'][$ip]=$a;return null;}unset($db['attempts'][$ip]);return $u;
    });
    if(isset($result['blocked']))fail(429,'Demasiados intentos. Espera 15 minutos.');if(!$result)fail(401,'Datos incorrectos o cuenta vencida/desactivada.');
    open_session();session_regenerate_id(true);$_SESSION['plyxe']=['role'=>$result['role'],'id'=>$result['id'],'version'=>$result['version']];unset($_SESSION['adult_until']);session_write_close();unset($result['version']);reply(['user'=>$result,'csrf'=>$csrf]);
}
if($action==='logout'){open_session();$uid=$_SESSION['plyxe']['id']??'';unset($_SESSION['plyxe'],$_SESSION['adult_until']);session_write_close();$device=(string)($in['device']??'');state(function(&$db)use($uid,$device){foreach($db['leases']as $k=>$l)if($l['uid']===$uid&&$l['device']===$device)unset($db['leases'][$k]);});reply(['ok'=>true]);}
$who=actor(str_starts_with($action,'admin.'));
if($who['role']==='admin'&&$who['mustChange']&&$action!=='admin.credentials')fail(403,'Cambia primero la contraseña inicial de administración.');
if($action==='admin.credentials'){
    $login=trim((string)($in['login']??''));$password=(string)($in['password']??'');if($login===''||strlen($login)>120||strlen($password)<8)fail(400,'Usa un correo/usuario y una contraseña de al menos 8 caracteres.');
    $version=state(function(&$db)use($login,$password){$db['admin']['login']=$login;$db['admin']['password']=password_hash($password,PASSWORD_DEFAULT);$db['admin']['mustChange']=false;return ++$db['admin']['version'];});
    open_session();$_SESSION['plyxe']['version']=$version;session_write_close();reply(['ok'=>true,'user'=>['role'=>'admin','id'=>'admin','mustChange'=>false]]);
}
if($action==='admin.state')reply(state(function(&$db){clean_leases($db);$settings=$db['settings'];unset($settings['pin']);$settings['provider']['passwordSet']=$settings['provider']['password']!=='';$settings['provider']['playlistSet']=$settings['provider']['playlist']!=='';$settings['provider']['bridgeKeySet']=!empty($settings['provider']['bridgeKey']);$settings['provider']['bridgeKey']='';$settings['provider']['password']='';$settings['provider']['playlist']='';$leases=[];foreach($db['leases']as $l)$leases[]=['uid'=>$l['uid'],'profile'=>$l['profile'],'started'=>$l['started']];return ['users'=>array_values(array_map('public_user',$db['users'])),'settings'=>$settings,'leases'=>$leases,'adminLogin'=>$db['admin']['login']];}));
if($action==='admin.user'){
    $id=(string)($in['id']??'');$username=trim((string)($in['username']??''));$password=(string)($in['password']??'');$name=trim((string)($in['name']??$username));$days=(int)($in['days']??30);$limit=(int)($in['maxDevices']??1);
    if($username===''||strlen($username)>80||$name===''||strlen($name)>100||$days<1||$days>3650||$limit<1||$limit>4||(!$id&&strlen($password)<4)||($password!==''&&strlen($password)<4))fail(400,'Revisa nombre, usuario, contraseña, días (1–3650) y dispositivos (1–4).');
    $result=state(function(&$db)use($id,$username,$password,$name,$days,$limit,$in){foreach($db['users']as $u)if(strcasecmp($u['username'],$username)===0&&$u['id']!==$id)return 'duplicate';$old=$id?($db['users'][$id]??null):null;if($id&&!$old)return 'missing';$id=$id?:bin2hex(random_bytes(8));$row=$old??['id'=>$id,'expires'=>time()+$days*86400,'profiles'=>['Perfil 1','Perfil 2','Perfil 3','Perfil 4'],'version'=>1];$row['username']=$username;$row['name']=$name;$row['maxDevices']=$limit;$row['active']=($in['active']??true)===true;if($password!==''){$row['password']=password_hash($password,PASSWORD_DEFAULT);$row['version']++;}if(!$row['active'])$row['version']++;if($old&&($in['renew']??false))$row['expires']=max(time(),$old['expires'])+$days*86400;if(isset($in['profiles'])&&count($in['profiles'])===4)$row['profiles']=array_map(fn($n)=>mb_safe_name((string)$n),$in['profiles']);$db['users'][$id]=$row;foreach($db['leases']as $k=>$l)if($l['uid']===$id)unset($db['leases'][$k]);return public_user($row);});
    if($result==='duplicate')fail(409,'Ese usuario ya existe.');if($result==='missing')fail(404,'Cuenta no encontrada.');reply(['user'=>$result]);
}
if($action==='admin.provider'){
    $p=$in['provider']??[];if(preg_match('/[\r\n]/',(string)($p['bridgeKey']??'')))fail(400,'Clave del puente no válida.');$mode=$p['mode']??'xtream';if(!in_array($mode,['xtream','m3u'],true))fail(400,'Tipo de proveedor no válido.');
    foreach(['server','bridge','playlist']as $field)if(!empty($p[$field])){$v=parse_url($p[$field]);if(!$v||!in_array($v['scheme']??'',['http','https'],true)||isset($v['user'])||isset($v['pass']))fail(400,'URL de proveedor o puente no válida.');}
    state(function(&$db)use($p,$mode){$old=$db['settings']['provider'];foreach(['server','username','bridge']as $k)$old[$k]=trim((string)($p[$k]??''));foreach(['password','playlist','bridgeKey']as $k)if(($p[$k]??'')!=='')$old[$k]=(string)$p[$k];$old['mode']=$mode;$db['settings']['provider']=$old;$db['settings']['revision']++;$db['leases']=[];});reply(['ok'=>true]);
}
if($action==='admin.pin'){$pin=(string)($in['pin']??'');if(!preg_match('/^\d{4,8}$/',$pin))fail(400,'El PIN debe tener entre 4 y 8 números.');state(function(&$db)use($pin){$db['settings']['pin']=password_hash($pin,PASSWORD_DEFAULT);});reply(['ok'=>true]);}
if($action==='admin.layout'){
    $kind=$in['kind']??'';if(!in_array($kind,['live','movie','series'],true))fail(400,'Sección no válida.');$layout=$in['layout']??[];$clean=['order'=>array_values(array_map('strval',$layout['order']??[])),'reverse'=>array_values(array_map('strval',$layout['reverse']??[])),'adult'=>array_values(array_map('strval',$layout['adult']??[])),'featured'=>(string)($layout['featured']??''),'titles'=>[]];foreach($layout['titles']??[]as $id=>$title){$title=trim((string)$title);if($title!=='')$clean['titles'][(string)$id]=substr($title,0,150);}state(function(&$db)use($kind,$clean){$db['settings']['layout'][$kind]=$clean;});reply(['ok'=>true]);
}
if($action==='catalog'){$kind=$in['kind']??'';if(!in_array($kind,['live','movie','series'],true))fail(400,'Sección no válida.');reply(catalog_for($kind));}
if($action==='pin'){
    open_session();$tries=$_SESSION['pin_tries']??['count'=>0,'until'=>time()+300];if($tries['until']<time())$tries=['count'=>0,'until'=>time()+300];if($tries['count']>=5){session_write_close();fail(429,'Espera cinco minutos antes de volver a intentar el PIN.');}$pinHash=app_settings()['pin'];$ok=password_verify((string)($in['pin']??''),$pinHash);if($ok){$_SESSION['adult_until']=time()+3600;$_SESSION['adult_grant']=$pinHash;unset($_SESSION['pin_tries']);}else{$tries['count']++;$_SESSION['pin_tries']=$tries;}session_write_close();if(!$ok)fail(403,'PIN incorrecto.');reply(['ok'=>true]);
}
if($action==='profile'){open_session();unset($_SESSION['adult_until']);session_write_close();reply(['ok'=>true]);}
if($action==='episodes'){$item=find_item('series',(string)($in['id']??''));require_pin($item['adult']);$out=[];foreach(episodes_for($item)as $season=>$rows)foreach($rows as $r)$out[$season][]=['id'=>(string)$r['id'],'title'=>$r['title']??'Episodio','duration'=>$r['info']['duration']??''];reply(['episodes'=>$out]);}
if($action==='play'){
    if($who['role']!=='user')fail(403,'Usa una cuenta de espectador para reproducir.');$kind=$in['kind']??'';if(!in_array($kind,['live','movie','series'],true))fail(400,'Contenido no válido.');$item=find_item($kind,(string)($in['id']??''));require_pin($item['adult']);$source=$item;
    if($kind==='series'){$source=null;foreach(episodes_for($item)as $rows)foreach($rows as $r)if((string)$r['id']===(string)($in['episode']??''))$source=$r;if(!$source)fail(404,'Episodio no encontrado.');}
    $url=source_for($kind,$source);if($kind==='live'&&($in['format']??'')==='ts'&&empty($source['source']))$url=preg_replace('/\.m3u8$/','.ts',$url);
    $ext=strtolower(pathinfo(parse_url($url,PHP_URL_PATH)??'',PATHINFO_EXTENSION));$format=in_array($ext,['m3u8','m3u'])?'hls':(in_array($ext,['ts','m2ts'])?'ts':($ext==='mpd'?'dash':'native'));
    $device=(string)($in['device']??'');if(!preg_match('/^[a-zA-Z0-9_-]{8,80}$/',$device))fail(400,'Identificador de dispositivo no válido.');$profile=(int)($in['profile']??0);if($profile<0||$profile>3)fail(400,'Perfil no válido.');$lease=create_lease($who['id'],$device,$profile,$url,$format,$item['adult']);if(!$lease)fail(401,'Cuenta no disponible.');reply(['lease'=>$lease,'url'=>'/api/media?lease='.$lease.'&resource=root','format'=>$format,'live'=>$kind==='live','title'=>$source['title']??$item['name']]);
}
if($action==='heartbeat'){$token=(string)($in['lease']??'');$ok=state(function(&$db)use($token,$who){clean_leases($db);$l=$db['leases'][$token]??null;if(!$l||$l['uid']!==$who['id'])return false;$db['leases'][$token]['heartbeat']=time();return true;});if(!$ok)fail(409,'La reproducción se cerró porque tu cuenta comenzó a usarse en otro dispositivo o la sesión caducó.');reply(['ok'=>true]);}
if($action==='stop'){$token=(string)($in['lease']??'');state(function(&$db)use($token,$who){if(($db['leases'][$token]['uid']??'')===$who['id'])unset($db['leases'][$token]);});reply(['ok'=>true]);}
fail(404,'Acción no encontrada.');
function mb_safe_name(string $name): string {return substr(trim($name)?:'Perfil',0,40);}
