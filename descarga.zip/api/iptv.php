<?php
require __DIR__ . '/common.php';
fail(410, 'Esta versión usa las cuentas Plyxe. Recarga la aplicación.');
