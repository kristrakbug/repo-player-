<?php
require __DIR__ . '/common.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail(405, 'Usa POST para conectar.');
$input = file_get_contents('php://input', false, null, 0, 16385);
if (strlen($input) > 16384) fail(413, 'Solicitud demasiado grande.');
$data = json_decode($input, true);
if (!is_array($data)) fail(400, 'Solicitud JSON no válida.');
$server = $data['server'] ?? null; $user = $data['username'] ?? null; $password = $data['password'] ?? null; $action = $data['action'] ?? null;
$actions = ['account', 'get_live_streams', 'get_live_categories', 'get_vod_streams', 'get_vod_categories', 'get_series', 'get_series_categories', 'get_series_info'];
if (!is_string($server) || !is_string($user) || trim($user) === '' || !is_string($password) || $password === '' || !in_array($action, $actions, true)) fail(400, 'Completa la URL, el usuario y la contraseña.');
$parts = parse_url($server);
if (isset($parts['query']) || isset($parts['fragment'])) fail(400, 'Introduce la URL base del servidor.');
$params = ['username' => $user, 'password' => $password];
if ($action !== 'account') $params['action'] = $action;
if ($action === 'get_series_info') {
    if (!preg_match('/^\d+$/', (string)($data['seriesId'] ?? ''))) fail(400, 'Serie no válida.');
    $params['series_id'] = $data['seriesId'];
}
$binding = hash('sha256', $server . "\0" . $user . "\0" . $password);
open_session();
if ($action !== 'account' && (($_SESSION['binding'] ?? '') !== $binding || ($_SESSION['expires'] ?? 0) < time())) { session_write_close(); fail(401, 'Vuelve a conectar tu cuenta IPTV.'); }
session_write_close();
$result = fetch_json(rtrim($server, '/') . '/player_api.php?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986));
if ($action === 'account') {
    open_session();
    if ((int)($result->user_info->auth ?? 0) === 1 && ($result->user_info->status ?? 'Active') === 'Active') {
        session_regenerate_id(true); $_SESSION['binding'] = $binding; $_SESSION['expires'] = time() + 86400;
    } else { unset($_SESSION['binding'], $_SESSION['expires']); }
    session_write_close();
}
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
